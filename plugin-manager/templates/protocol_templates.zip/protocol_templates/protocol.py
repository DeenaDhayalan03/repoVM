class ProtocolName(object):
    def __init__(self, component_name, configuration, logger):
        """
        """
        try:
            logger.debug("Initializing Protocol Instance")
            self.component_name = component_name
            self.configuration = configuration
            self.logger = logger
            self.block = None

        except Exception as es:
            self.logger.error(f"exception while creating protocol instance: {es}")

    def connect(self):
        """
        """
        try:
            pass
        except Exception as es:
            self.logger.error(f'error while performing connection operations: {es}')

    def disconnect(self):
        """
        """
        try:
            pass
        except Exception as es:
            self.logger.error(f'error while performing disconnection operations: {es}')

    def perform_task(self, block):
        self.logger.debug(f"Reading data for Protocol Instance {self.component_name}")
        self.block = block
        tag_level_data = {}
        try:
            print(self.block)
        except Exception as es:
            self.logger.error(f"error while read data function execution: {es}")

        return tag_level_data

